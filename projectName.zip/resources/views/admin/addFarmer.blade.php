@extends('layouts.sys')
@section('styles')
    <link href="{{asset('sys/plugins/bower_components/jquery-wizard-master/css/wizard.css')}}" rel="stylesheet">
    <link href="{{asset('sys/plugins/bower_components/dropify/dist/css/dropify.min.css')}}" rel="stylesheet">
@endsection
@section('content')
<div id="wrapper">
    @include('layouts.header')
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3> </div>
                <div class="user-profile">
                </div>
                <ul class="nav" id="side-menu">
                    <li><a href="{{url('/admin')}}" class="waves-effect active"><i data-icon="7" class="mdi mdi-av-timer fa-fw"></i><span class="hide-menu">Dashboard </span></a> </li>
                    <li> <a href="javascript:void(0)" class="waves-effect"><i data-icon="/" class="mdi mdi-account-multiple"></i><span class="hide-menu"> Farmers<span class="fa arrow"></span><span class="label label-rouded label-purple pull-right"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="{{url('/admin/farmer/add')}}"><i data-icon=")" class="mdi mdi-account-plus"></i><span class="hide-menu"> New Farmer </span></a></li>
                            <li><a href="{{url('/admin/farmers')}}"><i class="mdi mdi-account-multiple"></i><span class="hide-menu"> Farmers Accounts </span></a></li>
                        </ul>
                    </li>
                    <li> <a href="javascript:void(0)" class="waves-effect"><i data-icon="" class="mdi mdi-account-multiple"></i><span class="hide-menu"> Agronomists<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li> <a href="{{url('/admin/agronomist/add')}}"><i data-icon="/" class="mdi mdi-account-plus"></i><span class="hide-menu"> New Agronomist </span></a> </li>
                            <li> <a href="{{url('/admin/agronomists')}}"><i data-icon="7" class="mdi mdi-account-multiple"></i><span class="hide-menu"> Agronomists Accounts </span></a> </li>
                        </ul>
                    </li>
                    <li> <a href="javascript:void(0)" class="waves-effect"><i data-icon="" class="mdi mdi-pine-tree"></i><span class="hide-menu"> Crop Info<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li> <a href="new-agronomist.html"><i data-icon="/" class="mdi mdi-account-plus"></i><span class="hide-menu"> New Agronomist</span></a> </li>
                            <li> <a href="agronomists-accounts.html"><i data-icon="7" class="mdi mdi-account-multiple"></i><span class="hide-menu"> Agronomists Accounts</span></a> </li>
                        </ul>
                    </li>
                    <li> <a href="javascript:void(0)" class="waves-effect"><i data-icon="" class="mdi mdi-wallet"></i><span class="hide-menu"> Financials<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li> <a href="{{url('/admin/order/add')}}"><i data-icon="/" class="fa fa-edit"></i><span class="hide-menu"> New Order</span></a> </li>
                            <li> <a href="{{url('/admin/orders')}}"><i data-icon="7" class="fa  fa-list"></i><span class="hide-menu"> Orders</span></a> </li>
                        </ul>
                    </li>

                    <li>
                        <a  href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="waves-effect"><i class="mdi mdi-logout fa-fw"></i> <span class="hide-menu">Log out</span></a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    <!-- ============================================================== -->
    <!-- End Left Sidebar -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Form Wizard</h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <button class="right-side-toggle waves-effect waves-light btn-info btn-circle pull-right m-l-20"><i class="ti-settings text-white"></i></button>
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Forms</a></li>
                            <li class="active">Form Wizard</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>

                <!-- .row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h3 class="box-title m-b-0">Farmer's Details</h3>
                            <p class="text-muted m-b-30 font-13"> Please fill in accurately.</p>
                            <div id="exampleBasic2" class="wizard">
                                <ul class="wizard-steps" role="tablist">
                                    <li class="active" role="tab">
                                        <h4><span><i class="ti-user"></i></span>Personal Information</h4> </li>
                                    <li role="tab">
                                        <h4><span><i class="ti-cloud-up"></i></span>Upload Documents</h4> </li>
                                    <li role="tab">
                                        <h4><span><i class="ti-direction"></i></span>Farm Information</h4> </li>
                                    <li role="tab">
                                        <h4><span><i class="ti-credit-card"></i></span>Payment Details</h4> </li>

                                </ul>
                                <div class="wizard-content">
                                    <div class="wizard-pane active" role="tabpanel">
                                        <!--.row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-info">
                                                    <div class="panel-wrapper collapse in" aria-expanded="true">
                                                        <div class="panel-body">
                                                            <form action="#">
                                                                <div class="form-body">
                                                                    <h3 class="box-title">Person Info</h3>
                                                                    <hr>

                                                                    <div class="row">
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">Sir Name</label>
                                                                                <input type="text" id="firstName" class="form-control" placeholder="John doe"> <span class="help-block"> This is inline help </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">First Name</label>
                                                                                <input type="text" id="lastName" class="form-control" placeholder="12n"> <span class="help-block"> This field has error. </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">Last Name</label>
                                                                                <input type="text" id="lastName" class="form-control" placeholder="12n"> <span class="help-block"> This field has error. </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                    </div>
                                                                    <!--/row-->
                                                                    <hr>
                                                                    <div class="row">
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">Email Address</label>
                                                                                <input type="text" id="firstName" class="form-control" placeholder="John doe"> <span class="help-block"> This is inline help </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">ID Number</label>
                                                                                <input type="text" id="lastName" class="form-control" placeholder="12n"> <span class="help-block"> This field has error. </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                                <label class="control-label">Mobile Number</label>
                                                                                <input type="text" id="lastName" class="form-control" placeholder="12n"> <span class="help-block"> This field has error. </span> </div>
                                                                        </div>
                                                                        <!--/span-->
                                                                    </div>

                                                                </div>

                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--./row-->
                                    </div>


                                    <div class="wizard-pane" role="tabpanel">
                                        <!--.row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-info">
                                                    <div class="panel-wrapper collapse in" aria-expanded="true">
                                                        <div class="panel-body">
                                                            <form action="#">
                                                                <div class="form-body">
                                                                    <h3 class="box-title">Upload Documents</h3>

                                                                    <!--/row-->

                                                                    <div class="row">
                                                                        <div class="col-sm-6 col-md-6 col-xs-12">
                                                                            <div class="white-box">
                                                                                <h3 class="box-title">Passport Photo</h3>
                                                                                <label for="input-file-now">Your so fresh input file — Default version</label>
                                                                                <input type="file" id="input-file-now" class="dropify" /> </div>
                                                                        </div>
                                                                        <div class="col-sm-6 col-md-6 col-xs-12">
                                                                            <div class="white-box">
                                                                                <h3 class="box-title">ID Front</h3>
                                                                                <label for="input-file-now-custom-1">You can add a default value</label>
                                                                                <input type="file" id="input-file-now-custom-1" class="dropify" data-default-file="../plugins/bower_components/dropify/src/images/test-image-1.jpg" /> </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- /.row -->
                                                                    <div class="row">
                                                                        <div class="col-sm-6 col-md-6 col-xs-12">
                                                                            <div class="white-box">
                                                                                <h3 class="box-title">Passport Photo</h3>
                                                                                <label for="input-file-now">Your so fresh input file — Default version</label>
                                                                                <input type="file" id="input-file-now" class="dropify" /> </div>
                                                                        </div>
                                                                        <div class="col-sm-6 col-md-6 col-xs-12">
                                                                            <div class="white-box">
                                                                                <h3 class="box-title">ID Front</h3>
                                                                                <label for="input-file-now-custom-1">You can add a default value</label>
                                                                                <input type="file" id="input-file-now-custom-1" class="dropify" data-default-file="../plugins/bower_components/dropify/src/images/test-image-1.jpg" /> </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- /.row -->
                                                                </div>

                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--./row-->
                                    </div>
                                    <div class="wizard-pane" role="tabpanel">
                                        <!--.row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-info">
                                                    <div class="panel-wrapper collapse in" aria-expanded="true">
                                                        <div class="panel-body">
                                                            <form action="#">
                                                                <div class="form-body">
                                                                    <h3 class="box-title">Farm Info</h3>
                                                                    <hr>

                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label>County</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Constituency</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Location</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Sub-location</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>County</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Village</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>

                                                                            <div class="form-group">
                                                                                <label>Farm Size (acres)</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>



                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label>Place Name</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>




                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Latitude</label>
                                                                                        <select class="form-control">
                                                                                            <option>--Type in farm's Latitude--</option>
                                                                                            <option>India</option>
                                                                                            <option>Sri Lanka</option>
                                                                                            <option>USA</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Longtitude</label>
                                                                                        <select class="form-control">
                                                                                            <option>--Type in farm's longtitude--</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="row">

                                                                                <div class="white-box">
                                                                                    <h3 class="box-title">Market with Info window</h3>
                                                                                    <div id="markermap" class="gmaps"></div>

                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <!--/span-->

                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--./row-->
                                    </div>

                                    <div class="wizard-pane" role="tabpanel">
                                        <!--.row-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-info">
                                                    <div class="panel-wrapper collapse in" aria-expanded="true">
                                                        <div class="panel-body">
                                                            <form action="#">
                                                                <div class="form-body">
                                                                    <h3 class="box-title">Farm Info</h3>
                                                                    <hr>

                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label>County</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Constituency</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Location</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Sub-location</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>County</label>
                                                                                <select class="form-control">
                                                                                    <option>--Select your Country--</option>
                                                                                    <option>India</option>
                                                                                    <option>Sri Lanka</option>
                                                                                    <option>USA</option>
                                                                                </select>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label>Village</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>

                                                                            <div class="form-group">
                                                                                <label>Farm Size (acres)</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>



                                                                        </div>
                                                                        <!--/span-->
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <label>Place Name</label>
                                                                                <input type="text" class="form-control"></input>
                                                                            </div>
                                                                            <hr>




                                                                            <div class="row">
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Latitude</label>
                                                                                        <select class="form-control">
                                                                                            <option>--Type in farm's Latitude--</option>
                                                                                            <option>India</option>
                                                                                            <option>Sri Lanka</option>
                                                                                            <option>USA</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-md-6">
                                                                                    <div class="form-group">
                                                                                        <label>Longtitude</label>
                                                                                        <select class="form-control">
                                                                                            <option>--Type in farm's longtitude--</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                            </div>



                                                                        </div>
                                                                        <!--/span-->

                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--./row-->
                                    </div>





                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                <!-- /.row -->

                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <div class="right-sidebar">
                    <div class="slimscrollright">
                        <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
                        <div class="r-panel-body">
                            <ul id="themecolors" class="m-t-20">
                                <li><b>With Light sidebar</b></li>
                                <li><a href="javascript:void(0)" data-theme="default" class="default-theme">1</a></li>
                                <li><a href="javascript:void(0)" data-theme="green" class="green-theme">2</a></li>
                                <li><a href="javascript:void(0)" data-theme="gray" class="yellow-theme">3</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue" class="blue-theme">4</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple" class="purple-theme">5</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna" class="megna-theme">6</a></li>
                                <li><b>With Dark sidebar</b></li>
                                <br/>
                                <li><a href="javascript:void(0)" data-theme="default-dark" class="default-dark-theme">7</a></li>
                                <li><a href="javascript:void(0)" data-theme="green-dark" class="green-dark-theme">8</a></li>
                                <li><a href="javascript:void(0)" data-theme="gray-dark" class="yellow-dark-theme">9</a></li>
                                <li><a href="javascript:void(0)" data-theme="blue-dark" class="blue-dark-theme">10</a></li>
                                <li><a href="javascript:void(0)" data-theme="purple-dark" class="purple-dark-theme">11</a></li>
                                <li><a href="javascript:void(0)" data-theme="megna-dark" class="megna-dark-theme working">12</a></li>
                            </ul>
                            <ul class="m-t-20 all-demos">
                                <li><b>Choose other demos</b></li>
                            </ul>
                            <ul class="m-t-20 chatonline">
                                <li><b>Chat option</b></li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/varun.jpg" alt="user-img" class="img-circle"> <span>Varun Dhavan <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/genu.jpg" alt="user-img" class="img-circle"> <span>Genelia Deshmukh <small class="text-warning">Away</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/ritesh.jpg" alt="user-img" class="img-circle"> <span>Ritesh Deshmukh <small class="text-danger">Busy</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/arijit.jpg" alt="user-img" class="img-circle"> <span>Arijit Sinh <small class="text-muted">Offline</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/govinda.jpg" alt="user-img" class="img-circle"> <span>Govinda Star <small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/hritik.jpg" alt="user-img" class="img-circle"> <span>John Abraham<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/john.jpg" alt="user-img" class="img-circle"> <span>Hritik Roshan<small class="text-success">online</small></span></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)"><img src="../plugins/images/users/pawandeep.jpg" alt="user-img" class="img-circle"> <span>Pwandeep rajan <small class="text-success">online</small></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2017 &copy; Ample Admin brought to you by themedesigner.in </footer>
    </div>
    <!-- /#page-wrapper -->
</div>
@endsection
@section('scripts')
    <!-- Form Wizard JavaScript -->
    <script src="{{asset('sys/plugins/bower_components/jquery-wizard-master/dist/jquery-wizard.min.js')}}"></script>
    <!-- FormValidation plugin and the class supports validating Bootstrap form -->
    <script src="{{asset('sys/plugins/bower_components/jquery-wizard-master/libs/formvalidation/formValidation.min.js')}}"></script>
    <script src="{{asset('sys/plugins/bower_components/jquery-wizard-master/libs/formvalidation/bootstrap.min.js')}}"></script>

    <!-- Custom Theme JavaScript -->
    <script src="{{asset('sys/js/custom.min.js')}}"></script>
    <!-- jQuery file upload -->
    <script src="{{asset('sys/plugins/bower_components/dropify/dist/js/dropify.min.js')}}"></script>
    <!-- Sweet-Alert  -->
    <script src="{{asset('sys/plugins/bower_components/sweetalert/sweetalert.min.js')}}"></script>
    <script type="text/javascript">
        (function() {
            $('#exampleBasic').wizard({
                onFinish: function() {
                    swal("Message Finish!", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lorem erat eleifend ex semper, lobortis purus sed.");
                }
            });
            $('#exampleBasic2').wizard({
                onFinish: function() {
                    swal("Message Finish!", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lorem erat eleifend ex semper, lobortis purus sed.");
                }
            });
            $('#exampleValidator').wizard({
                onInit: function() {
                    $('#validation').formValidation({
                        framework: 'bootstrap',
                        fields: {
                            username: {
                                validators: {
                                    notEmpty: {
                                        message: 'The username is required'
                                    },
                                    stringLength: {
                                        min: 6,
                                        max: 30,
                                        message: 'The username must be more than 6 and less than 30 characters long'
                                    },
                                    regexp: {
                                        regexp: /^[a-zA-Z0-9_\.]+$/,
                                        message: 'The username can only consist of alphabetical, number, dot and underscore'
                                    }
                                }
                            },
                            email: {
                                validators: {
                                    notEmpty: {
                                        message: 'The email address is required'
                                    },
                                    emailAddress: {
                                        message: 'The input is not a valid email address'
                                    }
                                }
                            },
                            password: {
                                validators: {
                                    notEmpty: {
                                        message: 'The password is required'
                                    },
                                    different: {
                                        field: 'username',
                                        message: 'The password cannot be the same as username'
                                    }
                                }
                            }
                        }
                    });
                },
                validator: function() {
                    var fv = $('#validation').data('formValidation');
                    var $this = $(this);
                    // Validate the container
                    fv.validateContainer($this);
                    var isValidStep = fv.isValidContainer($this);
                    if (isValidStep === false || isValidStep === null) {
                        return false;
                    }
                    return true;
                },
                onFinish: function() {
                    $('#validation').submit();
                    swal("Registration successful!", "Habex Agro Limited.");
                }
            });
            $('#accordion').wizard({
                step: '[data-toggle="collapse"]',
                buttonsAppendTo: '.panel-collapse',
                templates: {
                    buttons: function() {
                        var options = this.options;
                        return '<div class="panel-footer"><ul class="pager">' + '<li class="previous">' + '<a href="#' + this.id + '" data-wizard="back" role="button">' + options.buttonLabels.back + '</a>' + '</li>' + '<li class="next">' + '<a href="#' + this.id + '" data-wizard="next" role="button">' + options.buttonLabels.next + '</a>' + '<a href="#' + this.id + '" data-wizard="finish" role="button">' + options.buttonLabels.finish + '</a>' + '</li>' + '</ul></div>';
                    }
                },
                onBeforeShow: function(step) {
                    step.$pane.collapse('show');
                },
                onBeforeHide: function(step) {
                    step.$pane.collapse('hide');
                },
                onFinish: function() {
                    swal("Submit Information!", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lorem erat eleifend ex semper, lobortis purus sed.");
                }
            });
            // Basic
            $('.dropify').dropify();
            // Translated
            $('.dropify-fr').dropify({
                messages: {
                    default: 'Glissez-déposez un fichier ici ou cliquez',
                    replace: 'Glissez-déposez un fichier ou cliquez pour remplacer',
                    remove: 'Supprimer',
                    error: 'Désolé, le fichier trop volumineux'
                }
            });
            // Used events
            var drEvent = $('#input-file-events').dropify();
            drEvent.on('dropify.beforeClear', function(event, element) {
                return confirm("Do you really want to delete \"" + element.file.name + "\" ?");
            });
            drEvent.on('dropify.afterClear', function(event, element) {
                alert('File deleted');
            });
            drEvent.on('dropify.errors', function(event, element) {
                console.log('Has Errors');
            });
            var drDestroy = $('#input-file-to-destroy').dropify();
            drDestroy = drDestroy.data('dropify')
            $('#toggleDropify').on('click', function(e) {
                e.preventDefault();
                if (drDestroy.isDropified()) {
                    drDestroy.destroy();
                } else {
                    drDestroy.init();
                }
            })
        })();
    </script>
@endsection
