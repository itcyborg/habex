<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:ROLE_ADMIN');
    }

    public function index()
    {
        return view('admin.dashboard');
    }

    public function agronomistForm()
    {
        return view('admin.addAgronomist');
    }

    public function viewAgronomists()
    {
        return view('admin.viewAgronomists');
    }

    public function farmerForm()
    {
        return view('admin.addFarmer');
    }

    public function viewFarmers()
    {
        return view('admin.viewFarmers');
    }

    public function orderForm()
    {
        return view('admin.newOrder');
    }

    public function viewOrders()
    {
        return view('admin.listOrders');
    }
}
