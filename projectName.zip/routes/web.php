<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Auth::routes();
Route::group(
    ['middleware'=>'auth'],
    function(){
        Route::get('/','HomeController@index');
    }
);

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/admin','AdminController@index');

Route::get('/admin/agronomist/add','AdminController@agronomistForm');
Route::get('/admin/agronomists','AdminController@viewAgronomists');

Route::get('/admin/farmer/add','AdminController@farmerForm');
Route::get('/admin/farmers','AdminController@viewFarmers');

Route::get('/admin/order/add','AdminController@orderForm');
Route::get('/admin/orders','AdminController@viewOrders');


Route::get('/agronomist','AgronomistController@index');

Route::get('/agronomist/agronomist/add','AgronomistController@agronomistForm');
Route::get('/agronomist/agronomists','AgronomistController@viewAgronomists');

Route::get('/agronomist/farmer/add','AgronomistController@farmerForm');
Route::get('/agronomist/farmers','AgronomistController@viewFarmers');

Route::get('/agronomist/order/add','AgronomistController@orderForm');
Route::get('/agronomist/orders','AgronomistController@viewOrders');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
